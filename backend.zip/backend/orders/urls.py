from django.urls import path
from .views import (
    CartAPIView, CheckoutAPIView, OrderAPIView,
    PaymentInitiateAPIView, PaymentVerifyAPIView
)

urlpatterns = [
    # Cart
    path('cart/', CartAPIView.as_view(), name='cart'),
    path('cart/<int:item_id>/', CartAPIView.as_view(), name='cart-item'),
    
    # Checkout
    path('checkout/', CheckoutAPIView.as_view(), name='checkout'),
    
    # Orders
    path('orders/', OrderAPIView.as_view(), name='orders-list'),
    path('orders/<int:order_id>/', OrderAPIView.as_view(), name='order-detail'),
    
    # Payment
    path('orders/<int:order_id>/payment/initiate/', PaymentInitiateAPIView.as_view(), name='payment-initiate'),
    path('orders/<int:order_id>/payment/verify/', PaymentVerifyAPIView.as_view(), name='payment-verify'),
]
