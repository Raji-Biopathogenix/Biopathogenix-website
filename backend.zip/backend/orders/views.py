from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status, permissions
from rest_framework_simplejwt.authentication import JWTAuthentication
from django.db import transaction
from django.utils import timezone
from django.shortcuts import get_object_or_404
from .models import Cart, CartItem, Order, OrderItem, Payment, OrderStatusHistory
from product.models import Product
from .serializers import (
    CartSerializer, CartItemSerializer, OrderListSerializer,
    OrderDetailSerializer, OrderCreateSerializer, PaymentSerializer,
    PaymentVerifySerializer
)


class CartAPIView(APIView):
    authentication_classes = [JWTAuthentication]
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request):
        cart, created = Cart.objects.get_or_create(user=request.user)
        serializer = CartSerializer(cart)
        return Response({
            "status": "success",
            "data": serializer.data
        }, status=status.HTTP_200_OK)

    def post(self, request):
        """Add item to cart"""
        cart, created = Cart.objects.get_or_create(user=request.user)
        
        product_id = request.data.get('product_id')
        quantity = request.data.get('quantity', 1)

        try:
            product = Product.objects.get(id=product_id, is_active=True)
        except Product.DoesNotExist:
            return Response({
                "status": "error",
                "message": "Product not found"
            }, status=status.HTTP_404_NOT_FOUND)

        # Check stock
        if product.stock_quantity < quantity:
            return Response({
                "status": "error",
                "message": f"Only {product.stock_quantity} items available in stock"
            }, status=status.HTTP_400_BAD_REQUEST)

        # Add or update cart item
        cart_item, created = CartItem.objects.get_or_create(
            cart=cart,
            product=product,
            defaults={'quantity': quantity}
        )

        if not created:
            cart_item.quantity += quantity
            if cart_item.quantity > product.stock_quantity:
                return Response({
                    "status": "error",
                    "message": f"Cannot add more. Only {product.stock_quantity} items available"
                }, status=status.HTTP_400_BAD_REQUEST)
            cart_item.save()

        serializer = CartSerializer(cart)
        return Response({
            "status": "success",
            "message": "Item added to cart",
            "data": serializer.data
        }, status=status.HTTP_200_OK)

    def patch(self, request, item_id):
        """Update cart item quantity"""
        try:
            cart = Cart.objects.get(user=request.user)
            cart_item = CartItem.objects.get(id=item_id, cart=cart)
        except (Cart.DoesNotExist, CartItem.DoesNotExist):
            return Response({
                "status": "error",
                "message": "Cart item not found"
            }, status=status.HTTP_404_NOT_FOUND)

        quantity = request.data.get('quantity')
        if quantity is None or quantity < 1:
            return Response({
                "status": "error",
                "message": "Invalid quantity"
            }, status=status.HTTP_400_BAD_REQUEST)

        if quantity > cart_item.product.stock_quantity:
            return Response({
                "status": "error",
                "message": f"Only {cart_item.product.stock_quantity} items available"
            }, status=status.HTTP_400_BAD_REQUEST)

        cart_item.quantity = quantity
        cart_item.save()

        serializer = CartSerializer(cart)
        return Response({
            "status": "success",
            "message": "Cart updated",
            "data": serializer.data
        }, status=status.HTTP_200_OK)

    def delete(self, request, item_id=None):
        """Remove item from cart or clear entire cart"""
        try:
            cart = Cart.objects.get(user=request.user)
        except Cart.DoesNotExist:
            return Response({
                "status": "error",
                "message": "Cart not found"
            }, status=status.HTTP_404_NOT_FOUND)

        if item_id:
            # Delete specific item
            try:
                cart_item = CartItem.objects.get(id=item_id, cart=cart)
                cart_item.delete()
                message = "Item removed from cart"
            except CartItem.DoesNotExist:
                return Response({
                    "status": "error",
                    "message": "Cart item not found"
                }, status=status.HTTP_404_NOT_FOUND)
        else:
            # Clear entire cart
            cart.items.all().delete()
            message = "Cart cleared"

        serializer = CartSerializer(cart)
        return Response({
            "status": "success",
            "message": message,
            "data": serializer.data
        }, status=status.HTTP_200_OK)


class CheckoutAPIView(APIView):
    authentication_classes = [JWTAuthentication]
    permission_classes = [permissions.IsAuthenticated]

    @transaction.atomic
    def post(self, request):
        """Create order from cart"""
        try:
            cart = Cart.objects.get(user=request.user)
        except Cart.DoesNotExist:
            return Response({
                "status": "error",
                "message": "Cart is empty"
            }, status=status.HTTP_400_BAD_REQUEST)

        if not cart.items.exists():
            return Response({
                "status": "error",
                "message": "Cart is empty"
            }, status=status.HTTP_400_BAD_REQUEST)

        # Validate stock for all items
        for item in cart.items.all():
            if item.product.stock_quantity < item.quantity:
                return Response({
                    "status": "error",
                    "message": f"Insufficient stock for {item.product.name}"
                }, status=status.HTTP_400_BAD_REQUEST)

        # Create order
        serializer = OrderCreateSerializer(data=request.data)
        if not serializer.is_valid():
            return Response({
                "status": "error",
                "errors": serializer.errors
            }, status=status.HTTP_400_BAD_REQUEST)

        # Calculate totals
        subtotal = cart.subtotal
        shipping_cost = 0  # Calculate based on your logic
        tax = subtotal * 0.1  # 10% tax (adjust as needed)
        discount = 0
        total = subtotal + shipping_cost + tax - discount

        order = serializer.save(
            user=request.user,
            subtotal=subtotal,
            shipping_cost=shipping_cost,
            tax=tax,
            discount=discount,
            total=total
        )

        # Create order items
        for cart_item in cart.items.all():
            OrderItem.objects.create(
                order=order,
                product=cart_item.product,
                product_name=cart_item.product.name,
                product_sku=cart_item.product.sku,
                quantity=cart_item.quantity,
                price=cart_item.product.price,
            )
            
            # Reduce stock
            cart_item.product.stock_quantity -= cart_item.quantity
            cart_item.product.save(update_fields=['stock_quantity'])

        # Clear cart
        cart.items.all().delete()

        # Create status history
        OrderStatusHistory.objects.create(
            order=order,
            status='pending',
            notes='Order created',
            changed_by=request.user
        )

        return Response({
            "status": "success",
            "message": "Order created successfully",
            "data": OrderDetailSerializer(order).data
        }, status=status.HTTP_201_CREATED)


class OrderAPIView(APIView):
    authentication_classes = [JWTAuthentication]
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request, order_id=None):
        if order_id:
            # Get specific order
            order = get_object_or_404(Order, id=order_id, user=request.user)
            serializer = OrderDetailSerializer(order)
            return Response({
                "status": "success",
                "data": serializer.data
            }, status=status.HTTP_200_OK)
        
        # List user's orders
        orders = Order.objects.filter(user=request.user).order_by('-created_at')
        serializer = OrderListSerializer(orders, many=True)
        return Response({
            "status": "success",
            "data": serializer.data
        }, status=status.HTTP_200_OK)

    def patch(self, request, order_id):
        """Update order status (admin only)"""
        order = get_object_or_404(Order, id=order_id)
        
        new_status = request.data.get('status')
        notes = request.data.get('notes', '')

        if new_status and new_status in dict(Order.STATUS_CHOICES):
            order.status = new_status
            
            if new_status == 'shipped':
                order.shipped_at = timezone.now()
                order.tracking_number = request.data.get('tracking_number', '')
            elif new_status == 'delivered':
                order.delivered_at = timezone.now()
            
            order.save()

            # Create status history
            OrderStatusHistory.objects.create(
                order=order,
                status=new_status,
                notes=notes,
                changed_by=request.user
            )

            return Response({
                "status": "success",
                "message": "Order updated",
                "data": OrderDetailSerializer(order).data
            }, status=status.HTTP_200_OK)

        return Response({
            "status": "error",
            "message": "Invalid status"
        }, status=status.HTTP_400_BAD_REQUEST)


class PaymentInitiateAPIView(APIView):
    authentication_classes = [JWTAuthentication]
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request, order_id):
        """Initiate payment for an order"""
        order = get_object_or_404(Order, id=order_id, user=request.user)

        if order.payment_status == 'completed':
            return Response({
                "status": "error",
                "message": "Order is already paid"
            }, status=status.HTTP_400_BAD_REQUEST)

        payment_method = request.data.get('payment_method', 'card')

        # Create payment record
        payment = Payment.objects.create(
            order=order,
            payment_method=payment_method,
            amount=order.total,
            status='initiated'
        )

        # Here you would integrate with actual payment gateway (Stripe, PayPal, etc.)
        # For now, return mock payment data
        payment_data = {
            "payment_id": payment.id,
            "amount": str(order.total),
            "currency": "USD",
            "order_number": order.order_number,
            # In real implementation, return payment gateway client secret or redirect URL
            "client_secret": f"mock_secret_{payment.id}",
            "payment_method": payment_method
        }

        return Response({
            "status": "success",
            "message": "Payment initiated",
            "data": payment_data
        }, status=status.HTTP_200_OK)


class PaymentVerifyAPIView(APIView):
    authentication_classes = [JWTAuthentication]
    permission_classes = [permissions.IsAuthenticated]

    @transaction.atomic
    def post(self, request, order_id):
        """Verify payment status"""
        order = get_object_or_404(Order, id=order_id, user=request.user)

        serializer = PaymentVerifySerializer(data=request.data)
        if not serializer.is_valid():
            return Response({
                "status": "error",
                "errors": serializer.errors
            }, status=status.HTTP_400_BAD_REQUEST)

        transaction_id = serializer.validated_data['transaction_id']
        payment_status = serializer.validated_data['payment_status']
        gateway_response = serializer.validated_data.get('gateway_response')

        # Get or create payment record
        payment = Payment.objects.filter(order=order).first()
        if not payment:
            return Response({
                "status": "error",
                "message": "Payment record not found"
            }, status=status.HTTP_404_NOT_FOUND)

        # Update payment
        payment.transaction_id = transaction_id
        payment.status = payment_status
        payment.payment_gateway_response = gateway_response
        payment.save()

        # Update order
        if payment_status == 'completed':
            order.payment_status = 'completed'
            order.paid_at = timezone.now()
            order.status = 'processing'
        else:
            order.payment_status = 'failed'

        order.save()

        # Create status history
        OrderStatusHistory.objects.create(
            order=order,
            status=order.status,
            notes=f"Payment {payment_status}",
            changed_by=request.user
        )

        return Response({
            "status": "success",
            "message": f"Payment {payment_status}",
            "data": OrderDetailSerializer(order).data
        }, status=status.HTTP_200_OK)
