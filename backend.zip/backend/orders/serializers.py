from rest_framework import serializers
from .models import Cart, CartItem, Order, OrderItem, Payment, OrderStatusHistory
from product.serializers import ProductListSerializer


class CartItemSerializer(serializers.ModelSerializer):
    product = ProductListSerializer(read_only=True)
    product_id = serializers.IntegerField(write_only=True)
    total_price = serializers.DecimalField(max_digits=10, decimal_places=2, read_only=True)

    class Meta:
        model = CartItem
        fields = ['id', 'product', 'product_id', 'quantity', 'total_price', 'created_at']

    def validate_quantity(self, value):
        if value < 1:
            raise serializers.ValidationError("Quantity must be at least 1")
        return value


class CartSerializer(serializers.ModelSerializer):
    items = CartItemSerializer(many=True, read_only=True)
    total_items = serializers.IntegerField(read_only=True)
    subtotal = serializers.DecimalField(max_digits=10, decimal_places=2, read_only=True)

    class Meta:
        model = Cart
        fields = ['id', 'user', 'items', 'total_items', 'subtotal', 'created_at', 'updated_at']
        read_only_fields = ['user']


class OrderItemSerializer(serializers.ModelSerializer):
    class Meta:
        model = OrderItem
        fields = ['id', 'product', 'product_name', 'product_sku', 'quantity', 'price', 'total']


class OrderStatusHistorySerializer(serializers.ModelSerializer):
    changed_by_name = serializers.SerializerMethodField()

    class Meta:
        model = OrderStatusHistory
        fields = ['id', 'status', 'notes', 'changed_by', 'changed_by_name', 'created_at']

    def get_changed_by_name(self, obj):
        if obj.changed_by:
            return f"{obj.changed_by.first_name} {obj.changed_by.last_name}".strip() or obj.changed_by.email
        return "System"


class OrderListSerializer(serializers.ModelSerializer):
    items_count = serializers.SerializerMethodField()

    class Meta:
        model = Order
        fields = ['id', 'order_number', 'status', 'payment_status', 'total', 
                  'items_count', 'created_at']

    def get_items_count(self, obj):
        return obj.items.count()


class OrderDetailSerializer(serializers.ModelSerializer):
    items = OrderItemSerializer(many=True, read_only=True)
    status_history = OrderStatusHistorySerializer(many=True, read_only=True)

    class Meta:
        model = Order
        fields = '__all__'


class OrderCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = Order
        fields = ['shipping_first_name', 'shipping_last_name', 'shipping_email', 
                  'shipping_phone', 'shipping_address_line1', 'shipping_address_line2',
                  'shipping_city', 'shipping_state', 'shipping_postal_code', 'shipping_country',
                  'billing_first_name', 'billing_last_name', 'billing_address_line1',
                  'billing_address_line2', 'billing_city', 'billing_state', 
                  'billing_postal_code', 'billing_country', 'customer_notes', 'payment_method']


class PaymentSerializer(serializers.ModelSerializer):
    class Meta:
        model = Payment
        fields = ['id', 'order', 'payment_method', 'amount', 'status', 
                  'transaction_id', 'created_at', 'updated_at']
        read_only_fields = ['transaction_id', 'status']


class PaymentVerifySerializer(serializers.Serializer):
    transaction_id = serializers.CharField(max_length=255)
    payment_status = serializers.ChoiceField(choices=['completed', 'failed'])
    gateway_response = serializers.JSONField(required=False)
