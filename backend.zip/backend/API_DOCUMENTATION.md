# API Documentation - E-Commerce Backend

## Base URL
```
http://localhost:8000/api/
```

## Authentication
Most endpoints require JWT authentication. Include the token in headers:
```
Authorization: Bearer <your_access_token>
```

---

## Phase 3.1 – Product & Blog APIs

### Products

#### List Products
```http
GET /api/products/
```
**Query Parameters:**
- `category` - Filter by category ID
- `is_featured` - true/false
- `search` - Search in name, description, SKU
- `min_price` - Minimum price
- `max_price` - Maximum price
- `in_stock` - true/false
- `sort_by` - price, -price, name, -name, created_at, -created_at
- `page` - Page number
- `page_size` - Items per page (default: 20)

**Response:**
```json
{
  "status": "success",
  "data": [
    {
      "id": 1,
      "name": "Product Name",
      "slug": "product-name",
      "category": 1,
      "category_name": "Category",
      "short_description": "...",
      "sku": "SKU123",
      "price": "99.99",
      "compare_price": "149.99",
      "discount_percentage": 33,
      "stock_quantity": 100,
      "is_in_stock": true,
      "is_featured": false,
      "primary_image": { "image_url": "...", "alt_text": "..." },
      "views_count": 150
    }
  ]
}
```

#### Get Product Detail
```http
GET /api/products/{id}/
GET /api/products/slug/{slug}/
```

#### Create Product (Admin)
```http
POST /api/products/
Authorization: Bearer {token}
Content-Type: application/json

{
  "name": "Product Name",
  "slug": "product-name",
  "category": 1,
  "description": "Full description",
  "short_description": "Short desc",
  "sku": "SKU123",
  "price": "99.99",
  "compare_price": "149.99",
  "stock_quantity": 100,
  "is_active": true,
  "is_featured": false
}
```

#### Update Product (Admin)
```http
PATCH /api/products/{id}/
Authorization: Bearer {token}
```

#### Delete Product (Admin)
```http
DELETE /api/products/{id}/
Authorization: Bearer {token}
```

#### Product Reviews
```http
# List reviews
GET /api/products/{product_id}/reviews/

# Add review (requires authentication)
POST /api/products/{product_id}/reviews/
Authorization: Bearer {token}

{
  "rating": 5,
  "title": "Great product!",
  "comment": "Detailed review..."
}
```

### Blog

#### List Blog Posts
```http
GET /api/blog/
```
**Query Parameters:**
- `category` - Filter by category ID
- `is_featured` - true/false
- `search` - Search in title, content
- `sort_by` - published_at, -published_at, views_count
- `page` - Page number

#### Get Blog Post Detail
```http
GET /api/blog/{id}/
GET /api/blog/slug/{slug}/
```

#### List Blog Categories
```http
GET /api/blog/categories/
```

#### Blog Comments
```http
# List comments
GET /api/blog/{post_id}/comments/

# Add comment (requires authentication)
POST /api/blog/{post_id}/comments/
Authorization: Bearer {token}

{
  "content": "Great article!"
}
```

---

## Phase 3.2 – User Authentication APIs

### User Registration
```http
POST /api/superadmin/signup/

{
  "email": "user@example.com",
  "first_name": "John",
  "last_name": "Doe",
  "password": "SecurePass123!",
  "Company_name": "Company Inc",
  "user_type": "customer"
}
```

**Response:**
```json
{
  "status": "success",
  "msg": "Registration successful. Account activation pending admin review.",
  "data": { "id": 1, "email": "user@example.com", ... }
}
```

### User Login
```http
POST /api/superadmin/login/

{
  "email": "user@example.com",
  "password": "SecurePass123!"
}
```

**Response:**
```json
{
  "status": "success",
  "msg": "customer login successful",
  "data": {
    "id": 1,
    "email": "user@example.com",
    "first_name": "John",
    "last_name": "Doe",
    "role": "customer"
  },
  "access_token": "eyJ0eXAiOiJKV1QiLCJhbGc...",
  "refresh_token": "eyJ0eXAiOiJKV1QiLCJhbGc..."
}
```

### Google Social Login
```http
POST /api/superadmin/login/google/

{
  "token": "google_id_token_from_frontend"
}
```

**Note:** Get Google token from frontend using Google Sign-In SDK

### Password Reset

#### Request OTP
```http
POST /api/superadmin/send-otp/

{
  "email": "user@example.com"
}
```

#### Verify OTP
```http
POST /api/superadmin/verify-otp/

{
  "email": "user@example.com",
  "otp": "123456"
}
```

#### Reset Password
```http
POST /api/superadmin/forgot-password/

{
  "email": "user@example.com",
  "password": "NewPassword123!",
  "confirm_password": "NewPassword123!",
  "otp": "123456"
}
```

### User Management (Admin Only)

#### List Users
```http
GET /api/superadmin/users/
Authorization: Bearer {token}
```

#### Get User Details
```http
GET /api/superadmin/users/{id}/
Authorization: Bearer {token}
```

#### Update User (Admin can approve/activate users)
```http
PATCH /api/superadmin/users/{id}/
Authorization: Bearer {token}

{
  "is_active": true,
  "role": "customer"
}
```

---

## Phase 3.3 – Order Placement Flow

### Cart Management

#### Get Cart
```http
GET /api/cart/
Authorization: Bearer {token}
```

**Response:**
```json
{
  "status": "success",
  "data": {
    "id": 1,
    "items": [
      {
        "id": 1,
        "product": { "id": 1, "name": "Product", "price": "99.99", ... },
        "quantity": 2,
        "total_price": "199.98"
      }
    ],
    "total_items": 2,
    "subtotal": "199.98"
  }
}
```

#### Add to Cart
```http
POST /api/cart/
Authorization: Bearer {token}

{
  "product_id": 1,
  "quantity": 2
}
```

#### Update Cart Item
```http
PATCH /api/cart/{item_id}/
Authorization: Bearer {token}

{
  "quantity": 3
}
```

#### Remove from Cart
```http
DELETE /api/cart/{item_id}/
Authorization: Bearer {token}
```

#### Clear Cart
```http
DELETE /api/cart/
Authorization: Bearer {token}
```

### Checkout

#### Create Order
```http
POST /api/checkout/
Authorization: Bearer {token}

{
  "shipping_first_name": "John",
  "shipping_last_name": "Doe",
  "shipping_email": "john@example.com",
  "shipping_phone": "+1234567890",
  "shipping_address_line1": "123 Main St",
  "shipping_address_line2": "Apt 4B",
  "shipping_city": "New York",
  "shipping_state": "NY",
  "shipping_postal_code": "10001",
  "shipping_country": "USA",
  "billing_first_name": "",  // Optional, uses shipping if empty
  "customer_notes": "Please deliver before 5 PM",
  "payment_method": "card"
}
```

**Response:**
```json
{
  "status": "success",
  "message": "Order created successfully",
  "data": {
    "id": 1,
    "order_number": "ORD-ABC123",
    "status": "pending",
    "payment_status": "pending",
    "subtotal": "199.98",
    "shipping_cost": "0.00",
    "tax": "19.99",
    "total": "219.97",
    "items": [...],
    "created_at": "2026-02-02T10:00:00Z"
  }
}
```

### Payment

#### Initiate Payment
```http
POST /api/orders/{order_id}/payment/initiate/
Authorization: Bearer {token}

{
  "payment_method": "card"  // card, paypal, stripe, cash
}
```

**Response:**
```json
{
  "status": "success",
  "message": "Payment initiated",
  "data": {
    "payment_id": 1,
    "amount": "219.97",
    "currency": "USD",
    "order_number": "ORD-ABC123",
    "client_secret": "mock_secret_1",  // Use with payment gateway
    "payment_method": "card"
  }
}
```

#### Verify Payment
```http
POST /api/orders/{order_id}/payment/verify/
Authorization: Bearer {token}

{
  "transaction_id": "txn_123456789",
  "payment_status": "completed",  // completed or failed
  "gateway_response": { ... }  // Optional
}
```

**Response:**
```json
{
  "status": "success",
  "message": "Payment completed",
  "data": {
    "id": 1,
    "order_number": "ORD-ABC123",
    "status": "processing",
    "payment_status": "completed",
    "paid_at": "2026-02-02T10:05:00Z",
    ...
  }
}
```

### Order Management

#### List User Orders
```http
GET /api/orders/
Authorization: Bearer {token}
```

#### Get Order Details
```http
GET /api/orders/{order_id}/
Authorization: Bearer {token}
```

#### Update Order Status (Admin)
```http
PATCH /api/orders/{order_id}/
Authorization: Bearer {token}

{
  "status": "shipped",  // pending, processing, shipped, delivered, cancelled
  "tracking_number": "TRACK123456",
  "notes": "Order shipped via FedEx"
}
```

---

## Status Codes

- `200 OK` - Success
- `201 Created` - Resource created
- `400 Bad Request` - Invalid input
- `401 Unauthorized` - Authentication required
- `403 Forbidden` - Permission denied
- `404 Not Found` - Resource not found
- `500 Internal Server Error` - Server error

---

## Notes

### Manual Approval Logic
- New customer registrations set `is_active=False`
- Admin must activate users via PATCH `/api/superadmin/users/{id}/` with `{"is_active": true}`
- Inactive users cannot login

### Google OAuth Setup
1. Create project in Google Cloud Console
2. Enable Google+ API
3. Create OAuth 2.0 credentials
4. Update `.env` with `GOOGLE_CLIENT_ID`
5. Use Google Sign-In SDK in frontend to get token
6. Send token to `/api/superadmin/login/google/`

### Payment Integration
Current implementation provides structure for:
- Stripe
- PayPal
- Cash on Delivery

Replace mock implementation in `PaymentInitiateAPIView` with actual payment gateway integration.

---

## Testing

Use Postman, curl, or any HTTP client to test endpoints:

```bash
# Example: Get products
curl http://localhost:8000/api/products/

# Example: Login
curl -X POST http://localhost:8000/api/superadmin/login/ \
  -H "Content-Type: application/json" \
  -d '{"email":"admin@test.com","password":"password"}'

# Example: Add to cart (with token)
curl -X POST http://localhost:8000/api/cart/ \
  -H "Authorization: Bearer your_token_here" \
  -H "Content-Type: application/json" \
  -d '{"product_id":1,"quantity":2}'
```
