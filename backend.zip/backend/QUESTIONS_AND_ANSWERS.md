# Common Questions & Answers - Backend Implementation

## Architecture & Design Questions

### Q1: Why did you separate cart and order models instead of combining them?
**A:** This follows best practices because:
- **Cart** is temporary and session-specific (changes frequently, can be abandoned)
- **Order** is permanent and immutable (audit trail, payment history)
- Separation allows order history even if cart is cleared
- Makes checkout logic cleaner and prevents accidental data loss
- Enables cart recovery/abandoned cart recovery features later

### Q2: How does the approval workflow work for new users?
**A:** The flow is:
1. User signs up → `is_active=False` by default
2. Email sent with temporary password
3. Admin manually reviews and approves via Django admin or API
4. Admin sets `is_active=True` via `PATCH /api/superadmin/users/{id}/`
5. User can now login after approval
6. SuperAdmin (first user) is auto-activated; customers require approval

### Q3: Why did you use UUID for order numbers instead of auto-increment IDs?
**A:** 
- **Security**: Prevents competitors from guessing total order count
- **Scalability**: Works across multiple databases/instances without ID conflicts
- **Customer-facing**: More secure and professional than sequential numbers
- **Format**: `ORD-ABC123XYZ` is memorable and easier to reference

### Q4: What happens to stock when an order is cancelled?
**A:** Currently not implemented. Should add:
```python
# In delete order or cancel order logic:
for item in order.items.all():
    item.product.stock_quantity += item.quantity
    item.product.save()
```

---

## Security Questions

### Q5: Is the API vulnerable to SQL injection?
**A:** **No**, because:
- Using Django ORM (not raw SQL)
- Django QuerySet is parameterized automatically
- All user inputs are validated through serializers
- Example: `queryset.filter(Q(name__icontains=search))` is safe

### Q6: How are passwords handled?
**A:** Securely because:
- Using `make_password()` with Django's default PBKDF2 algorithm
- Passwords hashed, never stored in plain text
- `check_password()` verifies against hash
- Temporary passwords auto-generated and sent via email
- Example: `user.set_password(password)` uses secure hashing

### Q7: What about CSRF protection?
**A:** 
- **CSRF Middleware** is enabled in settings.py
- CSRF tokens checked for state-changing requests (POST, PATCH, DELETE)
- JWT tokens provide additional API protection
- Frontend should include CSRF token in forms

### Q8: Is the JWT token expiration configured?
**A:** **Yes**, in settings.py:
```python
SIMPLE_JWT = {
    'ACCESS_TOKEN_LIFETIME': timedelta(minutes=5),
    'REFRESH_TOKEN_LIFETIME': timedelta(days=1),
}
```
Short-lived access tokens reduce damage from token theft.

### Q9: How is sensitive data protected in responses?
**A:**
- Passwords never included in any response
- Serializers specify `read_only_fields`
- Payment gateway responses can be masked
- Email addresses only shown to authenticated users (except public posts)

---

## API Design Questions

### Q10: Why use different serializers (List vs Detail)?
**A:**
- **List**: Lightweight response (product name, price, image) - faster
- **Detail**: Complete data (description, reviews, all images)
- Reduces bandwidth for list operations
- API best practice for nested data

### Q11: How do you handle pagination?
**A:**
- Using `PageNumberPagination` from DRF
- Default: 20 products per page, 10 blog posts, configurable via `page_size`
- Response format includes pagination metadata (count, next, previous)
- Example: `GET /api/products/?page=2&page_size=50`

### Q12: What error handling is implemented?
**A:**
```python
# 400 Bad Request - Invalid input
{"status": "error", "errors": serializer.errors}

# 404 Not Found - Resource missing
{"status": "error", "message": "Product not found"}

# 403 Forbidden - No permission
{"status": "error", "message": "You don't have permission"}

# 500 Server Error - Server issue (Django handles)
```

### Q13: How do you prevent over-ordering (quantity > stock)?
**A:**
- **Cart Add**: `if product.stock_quantity < quantity: return error`
- **Checkout**: Validate all items before creating order
- **Final Deduction**: Stock reduced only after successful payment
- **Race Condition**: Could be fixed with database-level locks in production

---

## Database Questions

### Q14: Why use on_delete=CASCADE vs PROTECT?
**A:**
- **CASCADE** (used for Cart, BlogComment): If parent deleted, delete child
  - Makes sense for temporary data
  - Cart items deleted when user deleted (acceptable)
  
- **PROTECT** (used for OrderItem → Product): Prevent deletion if child exists
  - Order items reference products for audit trail
  - Prevents accidental deletion of products with active orders
  - Admin must manually handle orphaned orders first

### Q15: What database indexes are used?
**A:** Strategic indexes for fast queries:
```python
# Product: search, filtering
Index(fields=['name']), Index(fields=['slug']), Index(fields=['sku'])

# Orders: user dashboard, admin filtering  
Index(fields=['order_number']), Index(fields=['user', 'status'])

# Blog: search and sorting
Index(fields=['slug']), Index(fields=['is_published', 'published_at'])
```
These speed up common queries without excessive overhead.

### Q16: How do you handle concurrent orders from same user?
**A:**
- Django handles database transactions with `@transaction.atomic`
- Each cart is `OneToOneField` per user (prevents duplicates)
- Order creation is transactional (all items created or none)
- Issue: Multiple simultaneous checkouts could cause race conditions
- Solution needed: Add database-level locking for production

---

## Business Logic Questions

### Q17: How is the discount percentage calculated?
**A:**
```python
discount_percentage = ((compare_price - price) / compare_price) * 100
# Example: ($150 - $99.99) / $150 * 100 = 33%
```
Shows customer savings (compare_price is original/list price).

### Q18: What if customer doesn't have billing address? 
**A:**
- Billing fields are optional (blank=True)
- Checkout logic should copy shipping to billing if blank
- Example:
```python
if not order.billing_first_name:
    order.billing_first_name = order.shipping_first_name
    # ... copy all fields
```
Currently not enforced; should be added.

### Q19: How are order statuses managed?
**A:**
```python
STATUS_CHOICES = [
    'pending' → order created, awaiting payment
    'processing' → payment received, preparing
    'shipped' → sent to customer
    'delivered' → arrived at customer
    'cancelled' → order cancelled
    'refunded' → order refunded
]
```
Admin can update via `PATCH /api/orders/{id}/` with tracking number and notes.

### Q20: What happens if payment fails?
**A:**
- Payment status set to 'failed'
- Order status remains 'pending'
- Stock NOT reduced (still in inventory)
- User can retry payment
- No automatic retry; manual dashboard shows failed payment

---

## Frontend Integration Questions

### Q21: How should frontend handle authentication?
**A:**
1. **Login**: Store `access_token` and `refresh_token` in secure storage
2. **Requests**: Include `Authorization: Bearer {access_token}` header
3. **Token Expiry**: When 401 received, use `refresh_token` to get new `access_token`
4. **Storage**: Use `HttpOnly` cookies or secure localStorage (not sessionStorage)

### Q22: How to implement Google login in frontend?
**A:**
```javascript
// Using Google Sign-In SDK
gapi.auth2.getAuthInstance().signIn().then(function(user) {
    const token = user.getAuthResponse().id_token;
    
    // Send to backend
    fetch('http://localhost:8000/api/superadmin/login/google/', {
        method: 'POST',
        body: JSON.stringify({token: token})
    });
});
```
Configure `GOOGLE_CLIENT_ID` in `.env` first.

### Q23: What's the expected response format?
**A:**
```json
{
  "status": "success/error",
  "message": "User-friendly message",
  "data": { /* actual data */ },
  "errors": { /* field errors if validation fails */ }
}
```
Consistent format across all endpoints for easy frontend parsing.

### Q24: How to handle product images?
**A:**
- Images stored as URLs (not uploaded to this backend)
- Frontend should upload images separately (AWS S3, Cloudinary, etc.)
- Backend stores image URLs in `ProductImage.image_url`
- Example: `https://cdn.example.com/products/abc123.jpg`

---

## Deployment & Performance Questions

### Q25: Is the backend production-ready?
**A:** **Not quite**. Still needed:
- [ ] Remove `DEBUG = True` from settings
- [ ] Configure proper SECRET_KEY
- [ ] Set up Gunicorn/uWSGI instead of dev server
- [ ] Enable HTTPS/SSL
- [ ] Configure proper database (PostgreSQL, not SQLite)
- [ ] Set up Redis for caching and sessions
- [ ] Configure email backend (not console)
- [ ] Add rate limiting
- [ ] Add logging

### Q26: How to scale for production?
**A:**
- Use **PostgreSQL** instead of SQLite (multiple connections)
- Use **Redis** for caching and sessions
- Add **Celery** workers for async tasks (email, reports)
- Implement **database connection pooling**
- Add **CDN** for images
- Use **Nginx** reverse proxy
- Enable **gzip** compression
- Add **monitoring** (Sentry, DataDog)

### Q27: What about API rate limiting?
**A:** Currently not implemented. Add:
```python
# In settings.py
REST_FRAMEWORK = {
    'DEFAULT_THROTTLE_CLASSES': [
        'rest_framework.throttling.AnonRateThrottle',
        'rest_framework.throttling.UserRateThrottle'
    ],
    'DEFAULT_THROTTLE_RATES': {
        'anon': '100/hour',
        'user': '1000/hour'
    }
}
```

### Q28: How to monitor API performance?
**A:**
- Log response times: `time.time()` before/after requests
- Monitor slow queries: Django Debug Toolbar in dev
- Use APM tools: New Relic, DataDog
- Track: API response times, DB query count, error rates
- Set up alerts for: High error rates, slow endpoints

---

## Testing Questions

### Q29: Are there unit tests?
**A:** **Not included in the implementation.** Should add:
```python
# tests/test_products.py
class ProductAPITest(APITestCase):
    def test_list_products(self):
        response = self.client.get('/api/products/')
        self.assertEqual(response.status_code, 200)
    
    def test_add_to_cart(self):
        self.client.force_authenticate(user=self.user)
        response = self.client.post('/api/cart/', {
            'product_id': 1, 'quantity': 2
        })
        self.assertEqual(response.status_code, 200)
```

### Q30: How to test payment flow?
**A:**
- Mock payment gateway in tests (not real charges)
- Test: Payment initiation, verification, order status
- Use `patch.object()` to mock external API calls
- Test edge cases: insufficient stock, expired tokens, duplicate payments

---

## Payment Integration Questions

### Q31: How do you integrate with Stripe?
**A:**
Replace mock in `PaymentInitiateAPIView`:
```python
import stripe

stripe.api_key = settings.STRIPE_SECRET_KEY

# Create payment intent
intent = stripe.PaymentIntent.create(
    amount=int(order.total * 100),  # in cents
    currency='usd',
    customer=user.stripe_customer_id
)

return Response({
    'client_secret': intent.client_secret,
    'payment_intent_id': intent.id
})
```

### Q32: How to handle failed payments and retries?
**A:**
- Keep payment record with `status='failed'`
- Don't reduce stock
- Show retry button on frontend
- Log failure reason in payment record
- Consider: Webhook from payment gateway for async updates

### Q33: How to implement refunds?
**A:** Add endpoint:
```python
# In views
def refund_order(self, request, order_id):
    order = Order.objects.get(id=order_id)
    
    # Call Stripe refund
    refund = stripe.Refund.create(
        payment_intent=order.payments.last().transaction_id
    )
    
    # Update order
    order.status = 'refunded'
    order.save()
    
    # Restore stock
    for item in order.items.all():
        item.product.stock_quantity += item.quantity
        item.product.save()
```

---

## Authentication & Authorization Questions

### Q34: What's the difference between roles: SUPERADMIN vs CUSTOMER?
**A:**
- **SUPERADMIN**: Can create products, manage users, approve registrations
- **CUSTOMER**: Can browse products, place orders, add reviews
- Currently role enforced via `CanCreateproduct()` permission class
- Could extend with: Manager, Staff, Vendor roles

### Q35: How to restrict endpoints by role?
**A:**
```python
from rest_framework.permissions import BasePermission

class IsAdmin(BasePermission):
    def has_permission(self, request, view):
        return request.user.role == ROLE_SUPERADMIN

class ProductAPIView(APIView):
    def get_permissions(self):
        if self.request.method in ['POST', 'PATCH', 'DELETE']:
            return [IsAdmin()]  # Only admin can modify
        return [AllowAny()]      # Anyone can view
```

### Q36: What if user forgets their password?
**A:**
1. Call `POST /api/superadmin/send-otp/` with email
2. Backend sends OTP via email (Celery task)
3. User enters OTP: `POST /api/superadmin/verify-otp/`
4. User resets password: `POST /api/superadmin/forgot-password/`
5. New password hashed and saved

---

## Data & Analytics Questions

### Q37: How are product views tracked?
**A:**
```python
# In ProductDetailSerializer
product.views_count += 1
product.save(update_fields=['views_count'])
```
Simple counter; incremented on each detail view. For analytics:
- Track: Which products viewed, when, by whom
- Store in separate analytics table for better performance

### Q38: How to generate sales reports?
**A:**
Add endpoints:
```python
# Revenue by date
GET /api/admin/reports/revenue/?start_date=2026-01-01&end_date=2026-02-01

# Top products
GET /api/admin/reports/top-products/?days=30

# Implementation:
orders = Order.objects.filter(
    created_at__gte=start_date,
    created_at__lte=end_date,
    status='delivered'
)
total_revenue = orders.aggregate(Sum('total'))['total__sum']
```

---

## Email & Notifications Questions

### Q39: How are emails sent?
**A:**
- Using **Celery** for async tasks
- Task: `send_welcome_email.delay(email, context)`
- Email backend configured in `.env`
- Supports: Gmail, SendGrid, custom SMTP
- Currently: `EmailBackend=console` (prints to console for dev)

### Q40: What emails are sent and when?
**A:**
1. **Registration**: Welcome email with temp password
2. **OTP Request**: OTP code for verification
3. **Order Confirmation**: Order details after checkout (not implemented)
4. **Shipping**: Tracking info when shipped (not implemented)
5. **Refund**: Refund confirmation (not implemented)

---

## Scalability & Future Features Questions

### Q41: How to add multiple vendors/sellers?
**A:**
Add model:
```python
class Vendor(models.Model):
    user = models.OneToOneField(User)
    store_name = models.CharField()
    commission_rate = models.DecimalField()

class Product(models.Model):
    vendor = models.ForeignKey(Vendor)  # Add this field
    # ... other fields
```

### Q42: How to implement wishlists?
**A:**
```python
class Wishlist(models.Model):
    user = models.OneToOneField(User, related_name='wishlist')
    products = models.ManyToManyField(Product)

class WishlistAPIView(APIView):
    def post(self, request, product_id):
        user.wishlist.products.add(product_id)
        return Response({'status': 'added'})
```

### Q43: How to add product variants (sizes, colors)?
**A:**
```python
class ProductVariant(models.Model):
    product = models.ForeignKey(Product, related_name='variants')
    size = models.CharField()
    color = models.CharField()
    sku = models.CharField(unique=True)
    stock = models.IntegerField()
    price = models.DecimalField()

# When adding to cart:
CartItem(product=product, variant=variant, quantity=qty)
```

### Q44: How to implement coupons/discount codes?
**A:**
```python
class Coupon(models.Model):
    code = models.CharField(unique=True)
    discount_percentage = models.IntegerField()
    min_purchase = models.DecimalField()
    max_uses = models.IntegerField()
    uses_count = models.IntegerField(default=0)
    valid_from = models.DateTimeField()
    valid_to = models.DateTimeField()

# During checkout:
coupon = Coupon.objects.get(code=code)
discount = subtotal * (coupon.discount_percentage / 100)
```

---

## Troubleshooting Questions

### Q45: What if migrations fail?
**A:**
```bash
# Check migration status
python manage.py showmigrations

# Reset migrations (dev only!)
python manage.py migrate zero

# Remake migrations
python manage.py makemigrations
python manage.py migrate

# Or fake initial migration
python manage.py migrate --fake-initial
```

### Q46: What if payment gateway returns 500 error?
**A:**
- Catch exception in `PaymentInitiateAPIView`
- Return 500 with message: "Payment service temporarily unavailable"
- Log error for debugging
- Suggest user retry later
- Don't charge customer or reduce stock

### Q47: What if stock goes negative somehow?
**A:**
```python
# Add validation in CartItem.save()
if self.quantity > self.product.stock_quantity:
    raise ValidationError("Insufficient stock")

# Add database constraint
class CartItem(models.Model):
    quantity = models.PositiveIntegerField()  # Can't be negative
```

### Q48: How to handle duplicate orders?
**A:**
```python
# Check if order already exists in PaymentVerifyAPIView
if Order.objects.filter(
    user=user, 
    created_at__gte=timezone.now() - timedelta(seconds=30),
    total=amount
).exists():
    return Response({'status': 'already_processed'}, status=400)
```

---

## Compliance & Legal Questions

### Q49: Is customer data secure? (GDPR compliance)
**A:** Partially:
- ✅ Passwords hashed
- ✅ No sensitive data logged
- ⚠️ Need: Data deletion endpoint (right to be forgotten)
- ⚠️ Need: Privacy policy and consent
- ⚠️ Need: HTTPS/SSL encryption
- ⚠️ Need: Regular security audits

### Q50: How to implement "Right to Delete" (GDPR)?
**A:**
```python
# Anonymize instead of delete
class UserDeleteView(APIView):
    def delete(self, request):
        user = request.user
        # Keep order history for business
        user.email = f"deleted_{user.id}@example.com"
        user.first_name = "Deleted"
        user.last_name = "User"
        user.set_unusable_password()
        user.save()
        return Response({'status': 'deleted'})
```

---

## Summary Checklist

**Before Production, Complete:**
- [ ] Add unit tests (at least 80% coverage)
- [ ] Implement rate limiting
- [ ] Add logging to all critical operations
- [ ] Configure email backend (SendGrid/Gmail)
- [ ] Setup payment gateway (Stripe/PayPal)
- [ ] Add HTTPS/SSL
- [ ] Configure proper database (PostgreSQL)
- [ ] Setup Redis for caching
- [ ] Add monitoring (Sentry/DataDog)
- [ ] Security audit (OWASP)
- [ ] Load testing
- [ ] Add API documentation (Swagger/OpenAPI)
- [ ] Implement refund logic
- [ ] Add order confirmation emails
- [ ] Handle abandoned carts
- [ ] Setup backup strategy
