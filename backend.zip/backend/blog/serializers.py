from rest_framework import serializers
from .models import BlogCategory, BlogPost, BlogComment


class BlogCategorySerializer(serializers.ModelSerializer):
    posts_count = serializers.SerializerMethodField()

    class Meta:
        model = BlogCategory
        fields = ['id', 'name', 'slug', 'description', 'is_active', 'posts_count']

    def get_posts_count(self, obj):
        return obj.posts.filter(is_published=True).count()


class BlogCommentSerializer(serializers.ModelSerializer):
    user_name = serializers.SerializerMethodField()

    class Meta:
        model = BlogComment
        fields = ['id', 'user', 'user_name', 'content', 'is_approved', 'created_at']
        read_only_fields = ['user', 'is_approved']

    def get_user_name(self, obj):
        return f"{obj.user.first_name} {obj.user.last_name}".strip() or obj.user.email


class BlogPostListSerializer(serializers.ModelSerializer):
    category_name = serializers.CharField(source='category.name', read_only=True)
    author_name = serializers.SerializerMethodField()
    reading_time = serializers.SerializerMethodField()

    class Meta:
        model = BlogPost
        fields = ['id', 'title', 'slug', 'category', 'category_name', 'author', 'author_name',
                  'excerpt', 'featured_image', 'is_featured', 'views_count', 'reading_time',
                  'published_at', 'created_at']

    def get_author_name(self, obj):
        return f"{obj.author.first_name} {obj.author.last_name}".strip() or obj.author.email

    def get_reading_time(self, obj):
        # Estimate reading time (assuming 200 words per minute)
        word_count = len(obj.content.split())
        minutes = max(1, word_count // 200)
        return f"{minutes} min read"


class BlogPostDetailSerializer(serializers.ModelSerializer):
    category = BlogCategorySerializer(read_only=True)
    author_name = serializers.SerializerMethodField()
    comments = serializers.SerializerMethodField()
    reading_time = serializers.SerializerMethodField()

    class Meta:
        model = BlogPost
        fields = ['id', 'title', 'slug', 'category', 'author', 'author_name', 'excerpt',
                  'content', 'featured_image', 'is_featured', 'views_count', 'reading_time',
                  'meta_title', 'meta_description', 'comments', 'published_at', 'created_at', 'updated_at']

    def get_author_name(self, obj):
        return f"{obj.author.first_name} {obj.author.last_name}".strip() or obj.author.email

    def get_comments(self, obj):
        approved_comments = obj.comments.filter(is_approved=True)
        return BlogCommentSerializer(approved_comments, many=True).data

    def get_reading_time(self, obj):
        word_count = len(obj.content.split())
        minutes = max(1, word_count // 200)
        return f"{minutes} min read"


class BlogPostCreateUpdateSerializer(serializers.ModelSerializer):
    class Meta:
        model = BlogPost
        exclude = ['views_count', 'created_at', 'updated_at']
