from django.urls import path
from .views import BlogCategoryAPIView, BlogPostAPIView, BlogCommentAPIView

urlpatterns = [
    path('categories/', BlogCategoryAPIView.as_view(), name='blog-categories'),
    path('', BlogPostAPIView.as_view(), name='blog-list-create'),
    path('<int:pk>/', BlogPostAPIView.as_view(), name='blog-detail'),
    path('slug/<slug:slug>/', BlogPostAPIView.as_view(), name='blog-detail-slug'),
    path('<int:post_id>/comments/', BlogCommentAPIView.as_view(), name='blog-comments'),
]
