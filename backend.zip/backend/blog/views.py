from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status, permissions
from rest_framework.pagination import PageNumberPagination
from rest_framework_simplejwt.authentication import JWTAuthentication
from django.db.models import Q
from .models import BlogPost, BlogCategory, BlogComment
from .serializers import (
    BlogPostListSerializer, BlogPostDetailSerializer,
    BlogPostCreateUpdateSerializer, BlogCategorySerializer,
    BlogCommentSerializer
)
from superadmin.permission import CanCreateproduct


class BlogPagination(PageNumberPagination):
    page_size = 10
    page_size_query_param = 'page_size'
    max_page_size = 50


class BlogCategoryAPIView(APIView):
    permission_classes = [permissions.AllowAny]

    def get(self, request):
        categories = BlogCategory.objects.filter(is_active=True)
        serializer = BlogCategorySerializer(categories, many=True)
        return Response({
            "status": "success",
            "data": serializer.data
        }, status=status.HTTP_200_OK)


class BlogPostAPIView(APIView):
    def get_permissions(self):
        if self.request.method in ['POST', 'PATCH', 'DELETE']:
            return [CanCreateproduct()]
        return [permissions.AllowAny()]

    def get_authenticators(self):
        if self.request.method in ['POST', 'PATCH', 'DELETE']:
            return [JWTAuthentication()]
        return []

    def get(self, request, pk=None, slug=None):
        # Get single blog post
        if pk or slug:
            try:
                if pk:
                    post = BlogPost.objects.get(pk=pk, is_published=True)
                else:
                    post = BlogPost.objects.get(slug=slug, is_published=True)
                
                # Increment views count
                post.views_count += 1
                post.save(update_fields=['views_count'])
                
                serializer = BlogPostDetailSerializer(post)
                return Response({
                    "status": "success",
                    "data": serializer.data
                }, status=status.HTTP_200_OK)
            except BlogPost.DoesNotExist:
                return Response({
                    "status": "error",
                    "message": "Blog post not found"
                }, status=status.HTTP_404_NOT_FOUND)

        # List blog posts with filters
        queryset = BlogPost.objects.filter(is_published=True).select_related('category', 'author')
        
        # Filters
        category_id = request.query_params.get('category')
        is_featured = request.query_params.get('is_featured')
        search = request.query_params.get('search')
        sort_by = request.query_params.get('sort_by', '-published_at')

        if category_id:
            queryset = queryset.filter(category_id=category_id)
        
        if is_featured:
            queryset = queryset.filter(is_featured=True)
        
        if search:
            queryset = queryset.filter(
                Q(title__icontains=search) |
                Q(content__icontains=search) |
                Q(excerpt__icontains=search)
            )

        # Sorting
        valid_sort_fields = ['published_at', '-published_at', 'views_count', '-views_count', 'title', '-title']
        if sort_by in valid_sort_fields:
            queryset = queryset.order_by(sort_by)

        paginator = BlogPagination()
        page = paginator.paginate_queryset(queryset, request)
        
        if page is not None:
            serializer = BlogPostListSerializer(page, many=True)
            return paginator.get_paginated_response({
                "status": "success",
                "data": serializer.data
            })

        serializer = BlogPostListSerializer(queryset, many=True)
        return Response({
            "status": "success",
            "data": serializer.data
        }, status=status.HTTP_200_OK)

    def post(self, request):
        serializer = BlogPostCreateUpdateSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save(author=request.user)
            return Response({
                "status": "success",
                "message": "Blog post created successfully",
                "data": serializer.data
            }, status=status.HTTP_201_CREATED)
        return Response({
            "status": "error",
            "errors": serializer.errors
        }, status=status.HTTP_400_BAD_REQUEST)

    def patch(self, request, pk):
        try:
            post = BlogPost.objects.get(pk=pk)
        except BlogPost.DoesNotExist:
            return Response({
                "status": "error",
                "message": "Blog post not found"
            }, status=status.HTTP_404_NOT_FOUND)

        serializer = BlogPostCreateUpdateSerializer(post, data=request.data, partial=True)
        if serializer.is_valid():
            serializer.save()
            return Response({
                "status": "success",
                "message": "Blog post updated successfully",
                "data": serializer.data
            }, status=status.HTTP_200_OK)
        return Response({
            "status": "error",
            "errors": serializer.errors
        }, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, pk):
        try:
            post = BlogPost.objects.get(pk=pk)
            post.delete()
            return Response({
                "status": "success",
                "message": "Blog post deleted successfully"
            }, status=status.HTTP_200_OK)
        except BlogPost.DoesNotExist:
            return Response({
                "status": "error",
                "message": "Blog post not found"
            }, status=status.HTTP_404_NOT_FOUND)


class BlogCommentAPIView(APIView):
    authentication_classes = [JWTAuthentication]
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request, post_id):
        try:
            post = BlogPost.objects.get(pk=post_id, is_published=True)
        except BlogPost.DoesNotExist:
            return Response({
                "status": "error",
                "message": "Blog post not found"
            }, status=status.HTTP_404_NOT_FOUND)

        serializer = BlogCommentSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save(user=request.user, post=post)
            return Response({
                "status": "success",
                "message": "Comment submitted successfully. It will be visible after approval.",
                "data": serializer.data
            }, status=status.HTTP_201_CREATED)
        return Response({
            "status": "error",
            "errors": serializer.errors
        }, status=status.HTTP_400_BAD_REQUEST)

    def get(self, request, post_id):
        try:
            post = BlogPost.objects.get(pk=post_id, is_published=True)
        except BlogPost.DoesNotExist:
            return Response({
                "status": "error",
                "message": "Blog post not found"
            }, status=status.HTTP_404_NOT_FOUND)

        comments = BlogComment.objects.filter(post=post, is_approved=True)
        serializer = BlogCommentSerializer(comments, many=True)
        return Response({
            "status": "success",
            "data": serializer.data
        }, status=status.HTTP_200_OK)
