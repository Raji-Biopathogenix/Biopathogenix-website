from django.contrib import admin
from django.urls import path , include

urlpatterns = [
    path('admin/', admin.site.urls),
    path('api/superadmin/', include('superadmin.urls')),
    path('api/category/', include('category.urls')),
    path('api/products/', include('product.urls')),
    path('api/blog/', include('blog.urls')),
    path('api/', include('orders.urls')),
]

