from rest_framework import serializers
from .models import Product, ProductImage, ProductReview
from category.serializers import CategorySerializer


class ProductImageSerializer(serializers.ModelSerializer):
    class Meta:
        model = ProductImage
        fields = ['id', 'image_url', 'alt_text', 'is_primary', 'sort_order']


class ProductReviewSerializer(serializers.ModelSerializer):
    user_name = serializers.SerializerMethodField()

    class Meta:
        model = ProductReview
        fields = ['id', 'user', 'user_name', 'rating', 'title', 'comment', 
                  'is_verified_purchase', 'is_approved', 'created_at']
        read_only_fields = ['user', 'is_verified_purchase', 'is_approved']

    def get_user_name(self, obj):
        return f"{obj.user.first_name} {obj.user.last_name}".strip() or obj.user.email


class ProductListSerializer(serializers.ModelSerializer):
    category_name = serializers.CharField(source='category.name', read_only=True)
    primary_image = serializers.SerializerMethodField()
    discount_percentage = serializers.SerializerMethodField()

    class Meta:
        model = Product
        fields = ['id', 'name', 'slug', 'category', 'category_name', 'short_description',
                  'sku', 'price', 'compare_price', 'discount_percentage', 'stock_quantity',
                  'is_in_stock', 'is_featured', 'primary_image', 'views_count', 'created_at']

    def get_primary_image(self, obj):
        image = obj.images.filter(is_primary=True).first()
        if image:
            return ProductImageSerializer(image).data
        return None

    def get_discount_percentage(self, obj):
        if obj.compare_price and obj.compare_price > obj.price:
            return int(((obj.compare_price - obj.price) / obj.compare_price) * 100)
        return 0


class ProductDetailSerializer(serializers.ModelSerializer):
    category = CategorySerializer(read_only=True)
    images = ProductImageSerializer(many=True, read_only=True)
    reviews = serializers.SerializerMethodField()
    average_rating = serializers.SerializerMethodField()
    discount_percentage = serializers.SerializerMethodField()

    class Meta:
        model = Product
        fields = '__all__'

    def get_reviews(self, obj):
        approved_reviews = obj.reviews.filter(is_approved=True)
        return ProductReviewSerializer(approved_reviews, many=True).data

    def get_average_rating(self, obj):
        approved_reviews = obj.reviews.filter(is_approved=True)
        if approved_reviews.exists():
            return round(sum(r.rating for r in approved_reviews) / approved_reviews.count(), 1)
        return 0

    def get_discount_percentage(self, obj):
        if obj.compare_price and obj.compare_price > obj.price:
            return int(((obj.compare_price - obj.price) / obj.compare_price) * 100)
        return 0


class ProductCreateUpdateSerializer(serializers.ModelSerializer):
    class Meta:
        model = Product
        exclude = ['views_count', 'created_at', 'updated_at']
