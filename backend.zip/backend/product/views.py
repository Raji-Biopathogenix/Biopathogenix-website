from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status, permissions
from rest_framework.pagination import PageNumberPagination
from rest_framework_simplejwt.authentication import JWTAuthentication
from django.db.models import Q
from .models import Product, ProductReview
from .serializers import (
    ProductListSerializer, ProductDetailSerializer,
    ProductCreateUpdateSerializer, ProductReviewSerializer
)
from superadmin.permission import CanCreateproduct


class ProductPagination(PageNumberPagination):
    page_size = 20
    page_size_query_param = 'page_size'
    max_page_size = 100


class ProductAPIView(APIView):
    def get_permissions(self):
        if self.request.method in ['POST', 'PATCH', 'DELETE']:
            return [CanCreateproduct()]
        return [permissions.AllowAny()]

    def get_authenticators(self):
        if self.request.method in ['POST', 'PATCH', 'DELETE']:
            return [JWTAuthentication()]
        return []

    def get(self, request, pk=None, slug=None):
        # Get single product by ID or slug
        if pk or slug:
            try:
                if pk:
                    product = Product.objects.get(pk=pk, is_active=True)
                else:
                    product = Product.objects.get(slug=slug, is_active=True)
                
                # Increment views count
                product.views_count += 1
                product.save(update_fields=['views_count'])
                
                serializer = ProductDetailSerializer(product)
                return Response({
                    "status": "success",
                    "data": serializer.data
                }, status=status.HTTP_200_OK)
            except Product.DoesNotExist:
                return Response({
                    "status": "error",
                    "message": "Product not found"
                }, status=status.HTTP_404_NOT_FOUND)

        # List products with filters
        queryset = Product.objects.filter(is_active=True).select_related('category').prefetch_related('images')
        
        # Filters
        category_id = request.query_params.get('category')
        is_featured = request.query_params.get('is_featured')
        search = request.query_params.get('search')
        min_price = request.query_params.get('min_price')
        max_price = request.query_params.get('max_price')
        in_stock = request.query_params.get('in_stock')
        sort_by = request.query_params.get('sort_by', '-created_at')

        if category_id:
            queryset = queryset.filter(category_id=category_id)
        
        if is_featured:
            queryset = queryset.filter(is_featured=True)
        
        if search:
            queryset = queryset.filter(
                Q(name__icontains=search) |
                Q(description__icontains=search) |
                Q(sku__icontains=search)
            )
        
        if min_price:
            queryset = queryset.filter(price__gte=min_price)
        
        if max_price:
            queryset = queryset.filter(price__lte=max_price)
        
        if in_stock == 'true':
            queryset = queryset.filter(stock_quantity__gt=0)

        # Sorting
        valid_sort_fields = ['price', '-price', 'name', '-name', 'created_at', '-created_at', 'views_count', '-views_count']
        if sort_by in valid_sort_fields:
            queryset = queryset.order_by(sort_by)

        paginator = ProductPagination()
        page = paginator.paginate_queryset(queryset, request)
        
        if page is not None:
            serializer = ProductListSerializer(page, many=True)
            return paginator.get_paginated_response({
                "status": "success",
                "data": serializer.data
            })

        serializer = ProductListSerializer(queryset, many=True)
        return Response({
            "status": "success",
            "data": serializer.data
        }, status=status.HTTP_200_OK)

    def post(self, request):
        serializer = ProductCreateUpdateSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response({
                "status": "success",
                "message": "Product created successfully",
                "data": serializer.data
            }, status=status.HTTP_201_CREATED)
        return Response({
            "status": "error",
            "errors": serializer.errors
        }, status=status.HTTP_400_BAD_REQUEST)

    def patch(self, request, pk):
        try:
            product = Product.objects.get(pk=pk)
        except Product.DoesNotExist:
            return Response({
                "status": "error",
                "message": "Product not found"
            }, status=status.HTTP_404_NOT_FOUND)

        serializer = ProductCreateUpdateSerializer(product, data=request.data, partial=True)
        if serializer.is_valid():
            serializer.save()
            return Response({
                "status": "success",
                "message": "Product updated successfully",
                "data": serializer.data
            }, status=status.HTTP_200_OK)
        return Response({
            "status": "error",
            "errors": serializer.errors
        }, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, pk):
        try:
            product = Product.objects.get(pk=pk)
            product.delete()
            return Response({
                "status": "success",
                "message": "Product deleted successfully"
            }, status=status.HTTP_200_OK)
        except Product.DoesNotExist:
            return Response({
                "status": "error",
                "message": "Product not found"
            }, status=status.HTTP_404_NOT_FOUND)


class ProductReviewAPIView(APIView):
    authentication_classes = [JWTAuthentication]
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request, product_id):
        try:
            product = Product.objects.get(pk=product_id)
        except Product.DoesNotExist:
            return Response({
                "status": "error",
                "message": "Product not found"
            }, status=status.HTTP_404_NOT_FOUND)

        # Check if user already reviewed this product
        if ProductReview.objects.filter(product=product, user=request.user).exists():
            return Response({
                "status": "error",
                "message": "You have already reviewed this product"
            }, status=status.HTTP_400_BAD_REQUEST)

        serializer = ProductReviewSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save(user=request.user, product=product)
            return Response({
                "status": "success",
                "message": "Review submitted successfully. It will be visible after approval.",
                "data": serializer.data
            }, status=status.HTTP_201_CREATED)
        return Response({
            "status": "error",
            "errors": serializer.errors
        }, status=status.HTTP_400_BAD_REQUEST)

    def get(self, request, product_id):
        try:
            product = Product.objects.get(pk=product_id)
        except Product.DoesNotExist:
            return Response({
                "status": "error",
                "message": "Product not found"
            }, status=status.HTTP_404_NOT_FOUND)

        reviews = ProductReview.objects.filter(product=product, is_approved=True)
        serializer = ProductReviewSerializer(reviews, many=True)
        return Response({
            "status": "success",
            "data": serializer.data
        }, status=status.HTTP_200_OK)
