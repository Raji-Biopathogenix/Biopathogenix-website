from django.urls import path
from .views import ProductAPIView, ProductReviewAPIView

urlpatterns = [
    path('', ProductAPIView.as_view(), name='product-list-create'),
    path('<int:pk>/', ProductAPIView.as_view(), name='product-detail'),
    path('slug/<slug:slug>/', ProductAPIView.as_view(), name='product-detail-slug'),
    path('<int:product_id>/reviews/', ProductReviewAPIView.as_view(), name='product-reviews'),
]
